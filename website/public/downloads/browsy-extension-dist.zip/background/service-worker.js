const n = {
  PING: "BROWSY_PING",
  PONG: "BROWSY_PONG",
  USER_REQUEST: "BROWSY_USER_REQUEST"
}, t = "Browsy", a = "0.2.0";
chrome.runtime.onInstalled.addListener((e) => {
  console.info(
    `[${t}] Background Service Worker installed:`,
    e.reason,
    `v${a}`
  );
});
chrome.runtime.onMessage.addListener(
  (e, r, o) => {
    var c;
    const s = (c = r.tab) == null ? void 0 : c.id;
    switch (console.debug(`[${t}] Message received:`, e.action, "from tab:", s), e.action) {
      case n.PING: {
        const i = {
          action: n.PONG,
          version: a,
          timestamp: Date.now()
        };
        return o(i), !1;
      }
      case n.USER_REQUEST:
        return console.info(
          `[${t}] User Request on ${e.context.hostname}:`,
          e.prompt
        ), o({
          received: !0,
          status: "stage2_acknowledged",
          hostname: e.context.hostname,
          hasIntelligence: !!e.context.intelligence
        }), !1;
      default:
        return !1;
    }
  }
);
