const i = {
  PING: "BROWSY_PING",
  PONG: "BROWSY_PONG",
  USER_REQUEST: "BROWSY_USER_REQUEST",
  AI_STATUS: "BROWSY_AI_STATUS",
  AI_QUERY: "BROWSY_AI_QUERY",
  AI_SELECT_MODEL: "BROWSY_AI_SELECT_MODEL"
}, l = "Browsy", T = "0.2.0";
chrome.runtime.onInstalled.addListener((t) => {
  console.info(
    `[${l}] Background Service Worker installed:`,
    t.reason,
    `v${T}`
  );
});
const c = "http://127.0.0.1:8765";
chrome.runtime.onMessage.addListener(
  (t, h, e) => {
    var s, u, S, E;
    const m = (s = h.tab) == null ? void 0 : s.id;
    switch (console.debug(`[${l}] Message received:`, t.action, "from tab:", m), t.action) {
      case i.PING: {
        const o = {
          action: i.PONG,
          version: T,
          timestamp: Date.now()
        };
        return e(o), !1;
      }
      case i.USER_REQUEST:
        return console.info(
          `[${l}] User Request on ${(u = t.context) == null ? void 0 : u.hostname}:`,
          t.prompt
        ), e({
          received: !0,
          status: "stage2_acknowledged",
          hostname: (S = t.context) == null ? void 0 : S.hostname,
          hasIntelligence: !!((E = t.context) != null && E.intelligence)
        }), !1;
      case i.AI_STATUS: {
        const o = new AbortController(), r = setTimeout(() => o.abort(), 1800);
        return fetch(`${c}/api/status`, {
          method: "GET",
          headers: { "X-Browsy-Client": "extension" },
          signal: o.signal
        }).then((a) => a.json()).then((a) => {
          clearTimeout(r), e(a);
        }).catch(() => {
          clearTimeout(r), e({
            status: "unavailable",
            ollamaRunning: !1,
            activeModel: "qwen2.5:1.5b",
            availableModels: [],
            message: "Local companion service not running on loopback (http://127.0.0.1:8765)."
          });
        }), !0;
      }
      case i.AI_SELECT_MODEL:
        return fetch(`${c}/api/models/select`, {
          method: "POST",
          headers: { "Content-Type": "application/json", "X-Browsy-Client": "extension" },
          body: JSON.stringify({ model: t.model })
        }).then((o) => o.json()).then((o) => e(o)).catch((o) => e({ error: String(o) })), !0;
      case i.AI_QUERY: {
        const o = new AbortController(), r = t.timeoutMs || 8e3, a = setTimeout(() => o.abort(), r);
        return fetch(`${c}${t.endpoint}`, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "X-Browsy-Client": "extension",
            ...t.simulate ? { "X-Browsy-Simulate": t.simulate } : {}
          },
          body: JSON.stringify(t.payload || {}),
          signal: o.signal
        }).then(async (n) => {
          if (clearTimeout(a), !n.ok) {
            const d = await n.text();
            e({ error: `Companion HTTP ${n.status}: ${d}`, status: n.status });
            return;
          }
          const _ = await n.json();
          e(_);
        }).catch((n) => {
          clearTimeout(a), e({
            error: n instanceof Error ? n.message : String(n),
            isTimeout: (n == null ? void 0 : n.name) === "AbortError"
          });
        }), !0;
      }
      default:
        return !1;
    }
  }
);
